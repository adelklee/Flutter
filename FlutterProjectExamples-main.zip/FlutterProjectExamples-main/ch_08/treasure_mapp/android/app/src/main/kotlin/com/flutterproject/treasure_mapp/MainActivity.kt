package com.flutterproject.treasure_mapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
