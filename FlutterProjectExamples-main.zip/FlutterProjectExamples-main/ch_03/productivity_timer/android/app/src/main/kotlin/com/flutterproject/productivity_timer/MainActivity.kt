package com.flutterproject.productivity_timer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
