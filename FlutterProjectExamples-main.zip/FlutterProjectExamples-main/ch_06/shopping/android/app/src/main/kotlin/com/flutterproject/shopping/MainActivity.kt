package com.flutterproject.shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
