package com.flutterproject.simple_pong

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
