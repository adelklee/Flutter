package it.softwarehouse.events

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
