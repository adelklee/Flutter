package com.flutterproject.movies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
