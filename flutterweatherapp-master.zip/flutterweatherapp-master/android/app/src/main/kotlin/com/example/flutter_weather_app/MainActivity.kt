package com.example.flutter_weather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
